package world;

import java.util.ArrayList;
import java.util.Arrays;

import world.entities.Person;
import world.entities.Rock;

public class WorldRunner {

	public static void main(String[] args) {
		
		World world = new World();
		ArrayList<Continent> continents = new ArrayList<Continent>();
		continents.add(new Continent("Africa"));
		continents.get(0).addCountry(new Country("Ghana"));
		continents.add(new Continent("Antartic"));
		continents.add(new Continent("Oceania"));
		world.setContinents(continents);
		for (int i = 0; i < 3; i++) {
			Continent con = world.getContinents().get(i);
		}
		//Person michaelJ = new Person("Michael Jackson", 65, true, "HEEHEEE2009");
		
		world.addPerson(new Person("Michael Jackson", 65, true, "HEEHEEE2009", false));
		world.addPerson(new Person("Doramion", 44, true, "GORROCOPTERO0", true));

		for (int i = 0; i < world.currRocks; i++)
			world.rocks[i] = new Rock();
		
		for (Person indiv : world.population)
			indiv.breath();
		
		for (Rock rock : world.rocks)
			System.out.println(rock.getImage());
		
		
	}

}
