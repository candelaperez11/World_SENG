package world.entities;

public class Entity {
	
}
