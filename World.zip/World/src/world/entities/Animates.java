package world.entities;

public abstract class Animates extends Entity {

}
