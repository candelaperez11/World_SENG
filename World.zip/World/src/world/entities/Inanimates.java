package world.entities;

public class Inanimates extends Entity {

}
